var searchData=
[
  ['grades',['grades',['../struct__student.html#ad0f75a9ff0f6104eb9e3bb3c4f7ad97b',1,'_student']]]
];
