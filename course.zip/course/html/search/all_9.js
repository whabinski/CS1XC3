var searchData=
[
  ['num_5fgrades',['num_grades',['../struct__student.html#a6592ee968ed2226737f45243e7602636',1,'_student']]]
];
